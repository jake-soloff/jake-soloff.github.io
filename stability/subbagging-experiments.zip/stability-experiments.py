from scipy import stats
import numpy as np

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeRegressor

from collections import defaultdict

import matplotlib.pyplot as plt
import matplotlib.patches as patches

## specify plot options 
plt.rcParams.update({
    'axes.linewidth' : 2,
    'font.size': 22,
    "text.usetex": True,
    'font.family': 'serif', 
    'font.serif': ['Computer Modern'],
    'text.latex.preamble' : r'\usepackage{amsmath,amsfonts}'})

## custom color palette
lblue = (40/255,103/255,178/255)
cred  = (177/255, 4/255, 14/255)

## subsample m out of [n] without replacement B times
def subsample(n, m, B):
    idx = np.zeros((B, m), dtype=int)
    for b in range(B):
        row = np.random.choice(n, m, replace=False)
        idx[b, :] = row
    return(idx)

## fit base algorithm A to B bags; for each
## bag, compute prediction at test point x_te
def fit_bags(Z_tr, x_te, A, m, B):
    n    = len(Z_tr)
    idx  = subsample(n, m, B)
    yhat = np.zeros(B)
    for b in range(B):
        yhat[b] = A(Z_tr[idx[b], :], x_te)
    return(idx, yhat)

## assess stability of subbagging algorithm A 
## on training data Z_tr and test point x_te
## returns sorted list of LOO errors:
##    |\hat{f}(x_te) - \hat{f}^{-i}(x_te)|
def stability(Z_tr, x_te, A, m, B):
    n    = len(Z_tr)
    idx, yhat = fit_bags(Z_tr, x_te, A, m, B)
    y_full = np.mean(yhat)
    loo = []
    for i in range(n):
        # average over bags not containing i
        y_noti = np.mean(yhat[~np.any(idx==i, axis=1)])
        loo.append(abs(y_full - y_noti)) 
    return(np.sort(loo))

## base algorithm for logistic regression with ridge penalty
## solving 
##    betahat = argmin{ 1/n sum_i loss_i + (lambda/2)*||beta||^2}
## where lambda = 1e-3
def LR(Z_tr, x_te):
    n = Z_tr.shape[0]
    X_tr, y_tr = Z_tr[:, :-1], Z_tr[:, -1]
    m = LogisticRegression(penalty='l2', C=1e3/n, fit_intercept=False)
    m.fit(X_tr, y_tr)
    return(m.predict_proba(x_te)[0][0])

## base algorithm for regression trees
## where max_depth=50
def fit_tree(Z_tr, x_te):
    n = Z_tr.shape[0]
    X_tr, y_tr = Z_tr[:, :-1], Z_tr[:, -1]

    m = DecisionTreeRegressor(max_depth=50)
    m.fit(X_tr, y_tr)
    return(m.predict(x_te)[0])


##########################################
#### Stability of logistic regression ####
##########################################
np.random.seed(1234567891)
results_lr_subbag  = defaultdict(list)
results_lr = defaultdict(list)
p = 0.5
B = 500
ns = np.array([500, 1000]) 
for n in ns:
    d = 250 
    # sample from null logistic model
    beta = 0*np.random.randn(d+1,1)
    X_tr = np.random.randn(n,d)
    p_tr = 1/(1+np.exp(-(beta[0] + np.dot(X_tr, beta[1:]))))
    y_tr = (np.random.rand(n,1) < p_tr)*1
    
    Z_tr = np.hstack([X_tr, y_tr])
    x_te = np.random.randn(1,d)
    
    # run subbagging
    results_lr_subbag[n] = stability(Z_tr, x_te, LR, int(n*p), B)
    
    # run base algorithm on full dataset
    y_full = LR(Z_tr, x_te)

    # run base algorithm on LOO datasets
    loo = []
    for i in range(n):
        idx = np.delete(np.arange(n), i)
        y_noti = LR(Z_tr[idx], x_te)
        loo.append(abs(y_full - y_noti)) 
    results_lr[n] = np.sort(loo)

### make figure 1 
fig, ax = plt.subplots(figsize=(9,4), frameon=False)

bins = np.linspace(0, .4, 45)

for ind, n in enumerate([ns[0]]):
    ax.hist(results_lr[n][::-1], bins=bins, color=cred, alpha=.6, label='Logistic Regression')  
    ax.hist(results_lr_subbag[n][::-1], bins=bins, color=lblue, alpha=.6, label='Logistic Regr. with Subbagging')
plt.xlim([0, .4])

# swap legend handles
handles, labels = plt.gca().get_legend_handles_labels()
order = [0,1]
plt.legend([handles[idx] for idx in order],[labels[idx] for idx in order], prop={'size':20})

plt.xlabel('Leave-one-out error $|\\hat{f}(x) - \\hat{f}^{\\setminus i}(x)|$')

plt.tight_layout()
plt.savefig('fig1.pdf')

### make figure 2 
fig = plt.figure(figsize=(9,6))
ax = plt.subplot(111)

ls = ['--', '-']
for ind, n in enumerate(ns):
    ax.plot(results_lr_subbag[n][::-1]*np.sqrt(n), np.arange(n)/n, label='Subbagged LR\n($n=%d,d=%d$)'%(n,d), lw=3, c=lblue, ls=ls[ind])

k = 10000
delta = np.arange(k)/k
ax.plot(1/(4*delta)**.5, delta, 'k', ls='dotted', label='Stability guarantee\nfor subbagging', lw=3)

for ind, n in enumerate(ns):
    ax.plot(results_lr[n][::-1]*np.sqrt(n), np.arange(n)/n, label='Logistic regression\n($n=%d,d=%d$)'%(n,d), lw=3, ls=ls[ind], c=cred)

ax.set_ylim([0, .5])
ax.set_xlim([0.0, 10])

# shrink current axis
box = ax.get_position()
ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])

# reorder legend items
handles, labels = plt.gca().get_legend_handles_labels()
order = [3,4,2,0,1]

# place legend outside plot
ax.legend([handles[idx] for idx in order],[labels[idx] for idx in order], loc='center left', bbox_to_anchor=(1, 0.5), prop={'size':24})

plt.ylabel('Error probability $\\delta$', fontsize=26)
plt.xlabel('Error tolerance $\\sqrt{n}\\varepsilon$', fontsize=26)

plt.savefig('fig2.pdf', bbox_inches='tight')
plt.show()

#####################################
#### Stability of decision trees ####
#####################################
np.random.seed(1234567891)
n, d = 500, 40
X = np.random.rand(n, d)
y = np.zeros(n)
for j in range(d):
    y += np.sin(X[:, j]/(1+j))
y[::4] += 2*(.5-np.random.rand(int(n/4)))
y[::3] += .5*(.5-np.random.rand(1+n//3))

x_te = np.random.rand(1, d)

results  = defaultdict(list)
results_ = defaultdict(list)

Z = np.hstack([X, y[:, np.newaxis]])
yhat = fit_tree(Z, x_te)

loo, rs = [], []
for i in range(n):
    idx = np.delete(np.arange(n), i)
    y_noti = fit_tree(Z[idx], x_te)
    loo.append(abs(yhat - y_noti))
results_[n] = np.sort(loo)

B = 500
results[n] = stability(Z, x_te, fit_tree, int(n*p), B)

### make figure 4a 
fig, ax = plt.subplots(figsize=(9,4), frameon=False)

bins = np.linspace(0, .4, 45)

for ind, n in enumerate([ns[0]]):
    ax.hist(results_[n][::-1], bins=bins, color=cred, alpha=.6, label='Regression trees')  
    ax.hist(results[n][::-1], bins=bins, color=lblue, alpha=.6, label='Regr. trees with Subbagging')
plt.xlim([0, .4])

# swap legend handles
handles, labels = plt.gca().get_legend_handles_labels()
order = [0,1]
plt.legend([handles[idx] for idx in order],[labels[idx] for idx in order], prop={'size':20})

plt.xlabel('Leave-one-out error $|\\hat{f}(x) - \\hat{f}^{\\setminus i}(x)|$')

plt.tight_layout()
plt.savefig('fig3a.pdf')


### make figure 4b
fig = plt.figure(figsize=(9,6))
ax = plt.subplot(111)

ls = ['--', '-']

ax.plot(results[n][::-1]*np.sqrt(n), np.arange(n)/n, label='Subbagged RT\n($n=%d,d=%d$)'%(n,d), lw=3, c=lblue, ls=ls[ind])

k = 10000
delta = np.arange(k)/k
ax.plot(1/(4*delta)**.5, delta, 'k', ls='dotted', label='Stability guarantee\nfor subbagging', lw=3)

ax.plot(results_[n][::-1]*np.sqrt(n), np.arange(n)/n, label='Regression trees\n($n=%d,d=%d$)'%(n,d), lw=3, ls=ls[ind], c=cred)

ax.set_ylim([0, .5])
ax.set_xlim([0.0, 10])

# Shrink current axis by 20%
box = ax.get_position()
ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])

# reorder legend items
handles, labels = plt.gca().get_legend_handles_labels()
order = [2,1,0]

# place legend outside plot
ax.legend([handles[idx] for idx in order],[labels[idx] for idx in order], loc='center left', bbox_to_anchor=(1, 0.5), prop={'size':24})

plt.ylabel('Error probability $\\delta$', fontsize=26)
plt.xlabel('Error tolerance $\\sqrt{n}\\varepsilon$', fontsize=26)

plt.savefig('fig3b.pdf', bbox_inches='tight')
plt.show()


#######################
#### Phase diagram ####
#######################
from matplotlib.colors import LogNorm

fig = plt.figure(figsize=(9,9), frameon=False)

p = .5
dd = np.linspace(0, 1, 1000)
# upper bound from theorem 3.4
UPPER = np.sqrt((n/(n-1))*(1/dd)*p/(1-p)*(1/(4)))
plt.plot(UPPER, dd, '-', c=lblue, alpha=1, lw=3)
plt.fill_between(UPPER, dd, np.repeat(dd.max(), len(dd)), color=lblue, alpha=.1)

n = 500
m = int(n*p)
# lower bound from theorem 3.7
LOWER = np.sqrt(n)*p*(1-dd-1/n)*stats.hypergeom.pmf(np.floor(p*(1+np.floor(n*dd))), n-1, m, np.floor(n*dd))
plt.plot(LOWER, dd, '-', c=cred, alpha=1, lw=3)
plt.fill_between(LOWER, np.repeat(0, len(dd)), dd, color=cred, alpha=.1)

plt.text(2.5, .15, 'Derandomized bagging\nis $(\\varepsilon, \\delta)$-stable for\nany base algorithm.', c=lblue)
plt.text(.12, .009, 'Derandomized bagging\nis not $(\\varepsilon, \\delta)$-stable\nfor some base algorithm.', c=cred)

plt.xticks([-.01] + list(range(1,6)), [0] + ['$%d/\\sqrt{n}$'%i for i in range(1, 6)])
plt.xlim([0, 5])
plt.ylim([0, .2])
plt.yticks([0,.05,.1,.15,.2])
plt.ylabel('Error probability $\\delta$', fontsize=26)

plt.xlabel('Error tolerance $\\varepsilon$', fontsize=26)
plt.tight_layout()
plt.savefig('fig4.pdf')
plt.show()